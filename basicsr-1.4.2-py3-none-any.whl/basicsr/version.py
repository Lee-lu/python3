# GENERATED VERSION FILE
# TIME: Mon Sep  8 22:52:53 2025
__version__ = '1.4.2'
__gitsha__ = 'unknown'
version_info = (1, 4, 2)
